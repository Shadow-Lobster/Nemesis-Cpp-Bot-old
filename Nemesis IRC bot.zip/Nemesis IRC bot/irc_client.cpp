#include "Socket.h"
#include "SocketError.h"
#include <iostream>
#include <string>

using namespace std;

bool ping(string::size_type);

const string server = "irc.evilcorp.ga";
const string port = "6667";
const string channel = "#bots";

int main ()
{
  try
  {
    Socket sock(server,port);
    if ( !sock.get_address() ) throw SocketException ( "Could not find irc server." );
    if ( !sock.connect() ) throw SocketException ( "Could not connect to irc server." );

    string reply;

    sock >> reply;
    sock >> reply;
    sock << "USER Evil d d CPPbot\r\n";
    sock << "NICK Nemesis\r\n";
    string::size_type loc = reply.find( "PING :", 0 );
    if( loc != string::npos )
      {
      string pong = "PONG :" + reply.substr(6,-1);
      sock << pong;
      }
    while (true)
    {	
    	sock >> reply;
	string::size_type motd_End_Finder = reply.find( "Nemesis :End", 0 );
    	if( motd_End_Finder != string::npos )
     	  {
      		sock << "JOIN :" << channel << "\r\n";
      	  }
	string::size_type pinger = reply.find( "PING :", 0 );
    	if( pinger != string::npos )
     	  {
     	 	string pong = "PONG :" + reply.substr(6,-1);
     	 	sock << pong;
      	  }
      	string::size_type quit_Command = reply.find( ":Shadow_Lobster!ShadowLobs@Man.With.Claws PRIVMSG "+channel+" :Self Destruct Nemesis", 0 );
    	if( quit_Command != string::npos )
     	  {
     	  	sock << "PRIVMSG " << channel << " :yes master\r\n";
      		sock << "QUIT :Nemesis will come\r\n";
      		break;
      	  }
    }
   }
  catch ( SocketException& e )
  {
    cout << "Exception was caught:" << e.description() << "\n";
  }
  return 0;
}
