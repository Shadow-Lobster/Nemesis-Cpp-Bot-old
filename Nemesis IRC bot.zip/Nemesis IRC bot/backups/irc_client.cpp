#include "Socket.h"
#include "SocketError.h"
#include <iostream>
#include <string>

using namespace std;

const string server = "irc.evilcorp.ga";
const string port = "6667";

int main ()
{
  try
  {
    Socket sock(server,port);
    if ( !sock.get_address() ) throw SocketException ( "Could not find irc server." );
    if ( !sock.connect() ) throw SocketException ( "Could not connect to irc server." );

    string reply;

    sock >> reply;
    sock >> reply;
    sock << "USER cumpoop d d CppBot\r\n";
    sock << "NICK CumPooP\r\n";
    sock >> reply;

    string::size_type loc = reply.find( "PING :", 0 );
    if( loc != string::npos ){
      string pong = "PONG :" + reply.substr(6,-1);
      sock << pong;
      }

    while (true){
      sock >> reply;
    }    
  }
  catch ( SocketException& e )
  {
    cout << "Exception was caught:" << e.description() << "\n";
  }
  return 0;
}
