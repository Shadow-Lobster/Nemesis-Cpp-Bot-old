#include <iostream>
#include <string>
#include "Socket.h"
#include "SocketError.h"

void ping()
{
    	string::size_type pinger = reply.find( "PING :", 0 );
    	if ( pinger != string::npos )
  	  {
  	  	sock << "PONG :irc.evilcorp.ga\r\n";
  	  }
}
